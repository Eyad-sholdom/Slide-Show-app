const clearLocalStorage = () => {
  localStorage.clear();
};

const logoutclicked = document.getElementById("logout");
logoutclicked.addEventListener("click", () => {
  clearLocalStorage();
  window.location.href = "/pages/validation.html";
});

