import Validation from "./Validation.js";

import User from "../models/UserModel.js";

/********** Form Example **********/
import useForm from "../js/useForm.js";
export const EMAIL_FIELD = document.getElementById("email-field");
export const PASSWORD_FIELD = document.getElementById("password-field");
export const PASSWORD_FIELD2 = document.getElementById("password-field2");
export const FORM_ERROR = document.getElementById("form-error");
export const CANCEL_BTN = document.getElementById("cancel");
export const SUBMIT_BTN = document.getElementById("submit");

const form = document.getElementById("login-form");
//localStorage.clear();
// לניקוי שדות ושגיאות
const INPUTS_ARRAY = [EMAIL_FIELD, PASSWORD_FIELD];/****/

// טופס ראשוני עם שמות כל השדות והערכים ריקים
const FORM_INIT = {
  email: "",
  password: "",
};

// סכמה שצורך ולידציה של המחלקה שאחראית על כל
const SCHEMA = {
  email: "email",
  password: "password",
};

const checkLocalStorage = () => {
  if (localStorage.getItem("Email") !== null) {
    console.log("User already exists in localStorage");

    const url = window.location.href;

    // check if url is not index.html or / or /index.html
    if (!url.includes("/index.html")) {
      window.location.href = "/index.html";
    }

    return;
  }
};

checkLocalStorage();

const handleSubmit = async (event) => {
  event.preventDefault();
  const usersdata = await fetch("../db/slideShow.json").then((res) =>
    res.json()
  );

  const userEmail = INPUTS_ARRAY[0].value;

  const user = usersdata.users.find((item) => item.email === userEmail);
  if (!user) {
    console.log("User does not exist");
    FORM_ERROR.innerHTML = "User does not exist";
    return;
  }

  const userDto = new User(user);

  //if local is empty and the input is valid then store the user data in the local storage
  // Save user data to localStorage
  localStorage.setItem("First Name", user.name.first);
  localStorage.setItem("Last Name", user.name.last);
  localStorage.setItem("ID", user._id);
  localStorage.setItem("Email", user.email);
  console.log("User saved to localStorage");

  const url = window.location.href;

  if (!url.includes("/index.html")) {
    window.location.href = "/index.html";
  }
  //onReset(INPUTS_ARRAY, ERRORS_ARRAY);

  // aead.@gmaiul.com
  // Ae0723@

  //business@gmail.com
  //Aa1234!
};

//איפוס שדות הטופס והמשתנים הגלובליים והשגיאות
const onReset = (inputsArray, errorsArray) => {
  handleReset();
  inputsArray.map((input) => {
    input.value = "";
  });
  errorsArray.map((err) => {
    err.innerHTML = "";
  });
};

// פונקציה שתופעל עם שחרור כפתור שליחה

// מטודה שאחראית לשינויים בשדות הטופס
const onInputChange = (e) => {
  FORM_ERROR.innerHTML = "";
  const isFormValidate =
    EMAIL_FIELD.value.length > 0 && PASSWORD_FIELD.value.length > 0;

  if (isFormValidate) return SUBMIT_BTN.removeAttribute("disabled");
  SUBMIT_BTN.setAttribute("disabled", "disabled");
};

// האזנה לאירועים

EMAIL_FIELD.addEventListener("input", (e) => onInputChange(e));

PASSWORD_FIELD.addEventListener("input", (e) => onInputChange(e));

SUBMIT_BTN.addEventListener("click", handleSubmit);
