import useForm from "../js/useForm.js";
import User from "../models/UserModel.js";

export const EMAIL_FIELD = document.getElementById("email-field");
export const EMAIL_ERROR = document.getElementById("email-error");

export const FIRSTNAME_FIELD = document.getElementById("fname-field");
export const FIRSTNAME_ERROR = document.getElementById("fname-error");

export const LASTNAME_FIELD = document.getElementById("lname-field");
export const LASTNAME_ERROR = document.getElementById("lname-error");

export const STATE_FIELD = document.getElementById("state-field");

export const CITY_FIELD = document.getElementById("city-field");

export const COUNTRY_FIELD = document.getElementById("country-field");

export const STREET_FIELD = document.getElementById("street-name-field");

export const HOUSENUMBER_FIELD = document.getElementById("house-field");

export const ZIPCODE_FIELD = document.getElementById("zipcode-field");

export const PHONE_FIELD = document.getElementById("phone-field");
export const PHONE_ERROR = document.getElementById("phone-error");

export const ISBUSINESS_FIELD = document.getElementById("business-checkbox");

export const PASSWORD_FIELD = document.getElementById("password-field");
export const PASSWORD2_FIELD = document.getElementById("password-field2");
export const PASSWORD_ERROR = document.getElementById("password-error");

export const CANCEL_BTN = document.getElementById("cancel");
export const SUBMIT_BTN = document.getElementById("submit");

// לניקוי שדות ושגיאות
const INPUTS_ARRAY = [
  EMAIL_FIELD,
  PASSWORD_FIELD,
  PASSWORD2_FIELD,
  FIRSTNAME_FIELD,
  LASTNAME_FIELD,
  STATE_FIELD,
  COUNTRY_FIELD,
  CITY_FIELD,
  STREET_FIELD,
  HOUSENUMBER_FIELD,
  ZIPCODE_FIELD,
  PHONE_FIELD,
  ISBUSINESS_FIELD,
];
const ERRORS_ARRAY = [
  EMAIL_ERROR,
  PASSWORD_ERROR,
  FIRSTNAME_ERROR,
  LASTNAME_ERROR,
];

// טופס ראשוני עם שמות כל השדות והערכים ריקים
const FORM_INIT = {
  first_name: "",
  last_name: "",
  email: "",
  password: "",
  repassword: "",
  phone: "",
};

// סכמה שצורך ולידציה של המחלקה שאחראית על כל
// key: input.name || value: validation function name
const SCHEMA = {
  first_name: "validate_name",
  last_name: "validate_name",
  email: "email",
  password: "password",
  repassword: "repassword",
  phone: "phone",
};

// איפוס שדות הטופס והמשתנים הגלובליים והשגיאות
const onReset = (inputsArray, errorsArray) => {
  handleReset();
  inputsArray.map((input) => {
    input.value = "";
  });
  errorsArray.map((err) => {
    err.innerHTML = "";
  });
};

// פונקציה שתופעל עם שחרור כפתור שליחה
const handleSubmit = (data) => {
  console.table(data);
  let address = checkObject(data);
  const userObject = {
    name: { first: data.first_name, last: data.last_name },
    address: address,
    phone: data.phone,
    email: data.email,
    password: data.password,
    isBusiness: ISBUSINESS_FIELD.checked,
  };
  let user = new User(userObject);
  onReset(INPUTS_ARRAY, ERRORS_ARRAY);
};

function checkObject(data) {
  let address = {};
  if (data.state) {
    address.state = data.state;
  } else {
    address.state = "";
  }
  if (data.city) {
    address.city = data.city;
  } else {
    address.city = "";
  }
  if (data.country) {
    address.country = data.country;
  } else {
    address.country = "";
  }
  if (data.street) {
    address.street = data.street;
  } else {
    address.street = "";
  }
  if (data.houseNumber) {
    address.houseNumber = data.houseNumber;
  } else {
    address.houseNumber = "";
  }
  if (data.zipCode) {
    address.zipCode = data.zipCode;
  } else {
    address.zipCode = "";
  }
  console.log(address);
  return address;
}

// מטודה שאחראית לניהול הטופס והשדות שבו והכפתורים
const { handleInputChange, onSubmit, handleDisableSubmitBtn, handleReset } =
  useForm(FORM_INIT, SCHEMA, handleSubmit);

// מטודה שאחראית לשינויים בשדות הטופס
const onInputChange = (e, errorEl) => {
  const { error } = handleInputChange(e);
  errorEl.innerHTML = error;
  const isFormValidate = handleDisableSubmitBtn();
  if (!isFormValidate) return SUBMIT_BTN.removeAttribute("disabled");
  SUBMIT_BTN.setAttribute("disabled", "disabled");
};

// האזנה לאירועים
EMAIL_FIELD.addEventListener("input", (e) => onInputChange(e, EMAIL_ERROR));

FIRSTNAME_FIELD.addEventListener("input", (e) =>
  onInputChange(e, FIRSTNAME_ERROR)
);
LASTNAME_FIELD.addEventListener("input", (e) =>
  onInputChange(e, LASTNAME_ERROR)
);

PHONE_FIELD.addEventListener("input", (e) => onInputChange(e, PHONE_ERROR));

PASSWORD_FIELD.addEventListener("input", (e) =>
  onInputChange(e, PASSWORD_ERROR)
);

PASSWORD2_FIELD.addEventListener("input", (e) =>
  onInputChange(e, PASSWORD_ERROR)
);

SUBMIT_BTN.addEventListener("click", onSubmit);
CANCEL_BTN.addEventListener("click", () => onReset(INPUTS_ARRAY, ERRORS_ARRAY));
