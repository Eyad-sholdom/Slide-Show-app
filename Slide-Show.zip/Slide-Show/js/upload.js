import useForm from "./useForm.js";
export const SOURCE_FIELD = document.getElementById("source-field");
export const SOURCE_ERROR = document.getElementById("source-error");

export const DECSRIPTION_FIELD = document.getElementById("decsription-field");
export const DECSRIPTION_ERROR = document.getElementById("decsription-error");

export const CREDITS_FIELD = document.getElementById("credits-field");
export const CREDITS_ERROR = document.getElementById("credits-error");

export const PRICE_FIELD = document.getElementById("price-field");
export const PRICE_ERROR = document.getElementById("price-error");

export const CANCEL_BTN = document.getElementById("cancel");
export const SUBMIT_BTN = document.getElementById("submit");

const form = document.getElementById("upload-form");


// לניקוי שדות ושגיאות
const INPUTS_ARRAY = [
  SOURCE_FIELD,
  DECSRIPTION_FIELD,
  CREDITS_FIELD,
  PRICE_FIELD,
];
const ERRORS_ARRAY = [
  SOURCE_ERROR,
  DECSRIPTION_ERROR,
  CREDITS_ERROR,
  PRICE_ERROR,
];

// טופס ראשוני עם שמות כל השדות והערכים ריקים
const FORM_INIT = {
  source: "",
  decription: "",
  credits: "",
  price: "",
};

// סכמה שצורך ולידציה של המחלקה שאחראית על כל
const SCHEMA = {
  source: "source",
  decription: "decription",
  credits: "credits",
  price: "price",
};

// איפוס שדות הטופס והמשתנים הגלובליים והשגיאות


// פונקציה שתופעל עם שחרור כפתור שליחה
const handleSubmit = (data) => {
  console.table(data);
  onReset(INPUTS_ARRAY, ERRORS_ARRAY);
};


// מטודה שאחראית לשינויים בשדות הטופס
const onInputChange = (e, errorEl) => {
  const { error } = handleInputChange(e);
  errorEl.innerHTML = error;
  const isFormValidate = handleDisableSubmitBtn();
  if (!isFormValidate) return SUBMIT_BTN.removeAttribute("disabled");
  SUBMIT_BTN.setAttribute("disabled", "disabled");
};

// SOURCE_FIELD.addEventListener("input", (e) => onInputChange(e, SOURCE_ERROR));

// DECSRIPTION_FIELD.addEventListener("input", (e) =>
//   onInputChange(e, DECSRIPTION_ERROR)
// );

// CREDITS_FIELD.addEventListener("input", (e) => onInputChange(e, CREDITS_ERROR));

// PRICE_FIELD.addEventListener("input", (e) => onInputChange(e, PRICE_ERROR));

// SUBMIT_BTN.addEventListener("click", onSubmit);
// CANCEL_BTN.addEventListener(
//   "click",
//   () => (window.location.href = "../index.html")
// );

// import {
//   URL_CREATE_PIC_FIELD,
//   URL_CREATE_PIC_ERROR,
//   ALT_CREATE_PIC_FIELD,
//   ALT_CREATE_PIC_ERROR,
//   CREDIT_CREATE_PIC_FIELD,
//   CREDIT_CREATE_PIC_ERROR,
//   PRICE_CREATE_PIC_FIELD,
//   PRICE_CREATE_PIC_ERROR,
//   SUBMIT_CREATE_PIC_BTN,
//   CANCELֹ_BTN,
//   URL_EDIT_PIC_FIELD,
//   ALT_EDIT_PIC_FIELD,
//   CREDIT_EDIT_PIC_FIELD,
//   PRICE_EDIT_PIC_FIELD,
//   EDIT_IMAGE_DISPLAY,
//   URL_EDIT_PIC_ERROR,
//   SUBMIT_EDIT_PIC_BTN,
//   ALT_EDIT_PIC_ERROR,
//   CREDIT_EDIT_PIC_ERROR,
//   PRICE_EDIT_PIC_ERROR,
//   CANCELֹ_EDIT_BTN,
// } from "./domService.js";

// import Picture from "../models/PictureModel.js";
// import useForm from "../services/formService.js";
// import { onChangePage } from "../routes/router.js";
// import PAGES from "../models/pageModel.js";
// import { handleSubmitNewPic, onSubmitEditPic } from "../app.js";
// import { renderPic } from "../components/renderPic.js";

// window.pic = {};

// const { onChangeInputField, onClearFormFields } = useForm();
// /********* Create Picture **********/
// export const handleCreatePic = () => {
//   onChangePage(PAGES.CREATE_PIC);
//   createPicFormFieldsListeners();
//   CANCELֹ_BTN.addEventListener("click", handleCancelCreateNewPic);
//   SUBMIT_CREATE_PIC_BTN.addEventListener("click", handleSubmitNewPic);
// };

// export const createPicFormFieldsListeners = () => {
//   const schema = ["url", "alt", "credits", "price"];

//   URL_CREATE_PIC_FIELD.addEventListener("input", (e) => {
//     const validation = {
//       min: 10,
//       max: 256,
//       lowerCase: true,
//       regex: {
//         regex: /^http[s]?\:\/\/.{1,}.(jpg|png|jpeg)$/g,
//         message: "Please enter a valid url",
//       },
//     };

//     const element = {
//       input: e.target,
//       errorSpan: URL_CREATE_PIC_ERROR,
//       validation,
//     };

//     onChangeInputField(schema, element, SUBMIT_CREATE_PIC_BTN);
//   });

//   ALT_CREATE_PIC_FIELD.addEventListener("input", (e) => {
//     const validation = {
//       min: 2,
//       max: 256,
//     };

//     const element = {
//       input: e.target,
//       errorSpan: ALT_CREATE_PIC_ERROR,
//       validation,
//     };
//     onChangeInputField(schema, element, SUBMIT_CREATE_PIC_BTN);
//   });

//   CREDIT_CREATE_PIC_FIELD.addEventListener("input", (e) => {
//     const validation = {
//       min: 2,
//       max: 256,
//     };

//     const element = {
//       input: e.target,
//       errorSpan: CREDIT_CREATE_PIC_ERROR,
//       validation,
//     };
//     onChangeInputField(schema, element, SUBMIT_CREATE_PIC_BTN);
//   });

//   PRICE_CREATE_PIC_FIELD.addEventListener("input", (e) => {
//     const validation = {
//       min: 1,
//       max: 256,
//     };

//     const element = {
//       input: e.target,
//       errorSpan: PRICE_CREATE_PIC_ERROR,
//       validation,
//     };
//     onChangeInputField(schema, element, SUBMIT_CREATE_PIC_BTN);
//   });
// };

// export const handleCancelCreateNewPic = () => {
//   const fields = [
//     URL_CREATE_PIC_FIELD,
//     ALT_CREATE_PIC_FIELD,
//     CREDIT_CREATE_PIC_FIELD,
//     PRICE_CREATE_PIC_FIELD,
//   ];

//   const errorSpans = [
//     URL_CREATE_PIC_ERROR,
//     ALT_CREATE_PIC_ERROR,
//     CREDIT_CREATE_PIC_ERROR,
//     PRICE_CREATE_PIC_ERROR,
//   ];
//   onClearFormFields(SUBMIT_CREATE_PIC_BTN, fields, errorSpans);
//   onChangePage(PAGES.HOME);
// };

// export const onCreateNewPic = (pictures) => {
//   try {
//     let newArray = [...pictures];
//     const pic = new Picture(
//       {
//         url: URL_CREATE_PIC_FIELD.value,
//         alt: ALT_CREATE_PIC_FIELD.value,
//         credits: CREDIT_CREATE_PIC_FIELD.value,
//         price: +PRICE_CREATE_PIC_FIELD.value,
//       },
//       pictures
//     );
//     newArray.push(pic);
//     return newArray;
//   } catch (error) {
//     console.error(error.message);
//     PRICE_CREATE_PIC_ERROR.innerHTML = error.message;
//   }
// };
