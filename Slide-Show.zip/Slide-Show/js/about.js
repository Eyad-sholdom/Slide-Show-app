document.addEventListener("DOMContentLoaded", () => {
  let logButton = document.getElementById("logButton");
  let divButton = document.getElementById("divButton");
  if (localStorage.getItem("Email") === null) {
    logButton.innerHTML = "log in";
  } else {
    logButton.innerHTML = "sing out";
    divButton.innerHTML += `<ul class="navbar-nav me-auto mb-2 mb-lg-0">
    <li class="nav-item">
      <a class="nav-link" href="../pages/upload.js">
        upload
      </a>
    </li>
  </ul>`;
    logButton.addEventListener("click", () => {
      localStorage.clear();
    });
  }
  logButton.href = "/pages/validation.html";
});
