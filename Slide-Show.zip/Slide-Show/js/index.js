let pictures = [];
let counter = 0;
let img = document.getElementById("sliderImg");
let logButton = document.getElementById("logout");

document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("Email") === null) {
    logButton.innerHTML = "log in";
  } else {
    logButton.innerHTML = "sing out";
    //if the log in page  opens the local storage will be already empty
    //thats why there is not neet the change the function of the button
  }
});

function fetchPictures() {
  return new Promise((resolve, reject) => {
    fetch("../db/slideShow.json")
      .then((response) => response.json())
      .then((data) => {
        pictures = data.pictures;
        resolve();
      })
      .catch((error) => {
        console.error(error);
        reject();
      });
  });
}
//get the pictures array and change the img tag src to first picture every time the page opens
window.onload = fetchPictures().then(() => {
  img.src = pictures[0].url;
});

//change picture on click
function ChangePic(value) {
  if (value === 0) {
    counter--;
  } else if (value === 1) {
    counter++;
  }
  if (counter < 0) {
    counter = 2;
  } else if (counter > 2) {
    counter = 0;
  }
  img.src = pictures[counter].url;
}
